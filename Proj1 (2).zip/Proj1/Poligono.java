/**
*
*/

public abstract class Poligono
{
  public abstract int getPerimetro();
  public abstract int getArea();
}
